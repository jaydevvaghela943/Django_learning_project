"""rest_api URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

#importing the home view
from home import views

urlpatterns = [
    path('', views.home, name='home'),
    path('get_students/', views.get_students, name='get_students'),
    path('create_student/', views.create_student, name='create_student'),
    #path('update_student/', views.update_student, name='update_student'),
    #path('delete_student/', views.delete_student, name='delete_student'),
    path('login/', views.login_api, name='login_api'),
    path('admin/', admin.site.urls),
]
