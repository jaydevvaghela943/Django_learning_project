from contextvars import Token
from django.shortcuts import render

# REST framework imports
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import *
from .serializer import *

from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

#Checking the request method and sending response accordingly
from rest_framework.decorators import authentication_classes, permission_classes
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated


@api_view(['POST'])
def login_api(request):
    try:
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            token = Token.objects.get_or_create(user=user)
            return Response({"status": 200, "message": "Login successful!", "token": str(token[0])})
        else:
            return Response({"status": 400, "message": "Invalid credentials!"})
    except Exception as e:
        return Response({"status": 500, "message": "An error occurred during login.", "error": str(e)})

@api_view(['GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def get_students(request):
    response = {"status": 200}
    student_objects = Student.objects.all()
    student_serializer = StudentSerializer(student_objects, many=True)
    response['data'] = student_serializer.data
    return Response(response)

@api_view(['POST'])
def create_student(request):
    response = {"status": 200}
    data = request.data
    student_serializer = StudentSerializer(data=data)
    if student_serializer.is_valid():
        student_serializer.save()
        response['message'] = "Student created successfully!"
        response['data'] = student_serializer.data
        return Response(response)
   
    return Response({'error': student_serializer.errors, 'status': 400})

def update_student(request):
    data = request.data
    try:
        student = Student.objects.get(id=data.get('id'))
        student_serializer = StudentSerializer(student, data=data, partial=True)
        if student_serializer.is_valid():
            student_serializer.save()
            return Response({"status": 200, "message": "Student updated successfully!"})
        
        return Response({"status": 400, "message": "Failed to update student!", "errors": student_serializer.errors})
    except Exception as e:
        return Response({"status": 500, "message": "An error occurred while updating student.", "error": str(e)})


@api_view(['GET','POST','PATCH','DELETE'])
def home(request):
    response = {"status": 200, "message": "Welcome to the home page!"}
    if request.method == 'POST':
        response['message'] = "You made a POST request!"
    elif request.method == 'GET':
        response['message'] = "You made a GET request!"
    elif request.method == 'PATCH':
        response['message'] = "You made a PATCH request!"
    elif request.method == 'DELETE':
        response['message'] = "You made a DELETE request!"
    
    return Response(response)
