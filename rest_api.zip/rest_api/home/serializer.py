from rest_framework import serializers

#importing the Student model
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        exclude = ['id']
        #fields = '__all__'